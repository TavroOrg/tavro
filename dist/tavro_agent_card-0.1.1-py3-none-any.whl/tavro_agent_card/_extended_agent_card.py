from typing import Optional, List, Any
from pathlib import Path
import json
import os
from pathlib import Path
import json

from pydantic import BaseModel, Field, ConfigDict

from a2a.types import AgentCard


class AgentIdentification(BaseModel):
    """Core identifying, descriptive, and governance details of the agent."""
    model_config = ConfigDict(extra="forbid")

    agent_id: str | None = None
    """
    A unique, permanent identifier for the agent (e.g., HR-POL-003)
    """
    agent_internal_id: str | None = None
    """
    """
    owner: str | None = None
    """
    The team or department responsible for the agent's maintenance and cost
    """
    instruction: str | None = None
    """
    Detailed instructions or guidelines for the agent's behavior, decision-making,
    and interactions
    """

    goal_orientation: Optional[str] = None
    """
    The specific objective or success metric the agent is designed to achieve
    """
    role: Optional[str] = None
    """
    The defined character or communication style that governs its interaction
    """

    environment: Optional[str] = None
    """
    The deployment environment (e.g., DEV, UAT, PROD)
    """
    tags: Optional[List[str]] = Field(default_factory=list)
    """
    A list of keywords for search and categorization (e.g., HR, policy, internal)
    """
    governance_status: Optional[str] = None
    """
    The current governance lifecycle status (e.g., DRAFT, APPROVED, DECOMMISSIONED)
    """
    reviewer: Optional[str] = None
    """
    Name of the person who approved the latest governance status
    """
    cost_center: Optional[str] = None
    """
    Name of the department for cost containment and chargeback (this may be another object in the data model)
    """


class AgentConfiguration(BaseModel):
    """Configuration details governing agent behavior and capabilities."""
    model_config = ConfigDict(extra="forbid")

    access_scope: Optional[str] = None
    """
    The agent's overall data access level (e.g., LOW_PRIVILEGE)
    """
    memory_type: Optional[str] = None
    """
    The type of memory storage used (e.g., VECTOR_DB, KEY_VALUE_STORE)
    """
    data_freshness_policy: Optional[str] = None
    """
    The maximum acceptable age of the data (caching policy) for the source
    """
    autonomy_level: Optional[str] = None
    """
    The degree to which the agent can act independently without human approval
    (FULL, SEMI-AUTONOMOUS, REACTIVE)
    """
    reasoning_model: Optional[str] = None
    """
    The underlying logic or planning paradigm (ReAct, ReWOO, Deductive, Inductive,
    Goal-based)
    """


class LLMModel(BaseModel):
    """LLM Model definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    name: str | None = None
    """
    The foundational model used by the agent (e.g., gemini-2.5-flash)
    """
    version_number: str | None = None
    """
    The version number of the LLM model
    """


class ModelParametersOverride(BaseModel):
    """Overrides for model parameters."""
    model_config = ConfigDict(extra="forbid")

    temperature: Optional[float] = None
    """
    Sampling temperature override for the model
    """

    rationale: Optional[str] = None
    """
    Optional rationale or explanation for parameter override
    """


class InstructionSet(BaseModel):
    """Instruction set definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    identifier: Optional[str] = None
    """
    Unique identifier for the instruction set
    """

    name: Optional[str] = None
    """
    Name of the instruction set
    """

    description: Optional[str] = None
    """
    Description of the instruction set
    """

    trigger_condition: Optional[str] = None
    """
    Condition under which this instruction is triggered
    """

    priority: Optional[int] = None
    """
    Priority of the instruction set
    """

    instruction_text: Optional[str] = None
    """
    The instruction text executed by the agent
    """

    model_parameters_override: Optional[ModelParametersOverride] = None
    """
    Optional overrides for model parameters
    """


class Topic(BaseModel):
    """Topic definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    identifier: Optional[str] = None
    """
    Unique identifier for the topic
    """

    name: Optional[str] = None
    """
    Name of the topic
    """

    api_name: Optional[str] = None
    """
    API name for the topic
    """

    description: Optional[str] = None
    """
    Description of the topic
    """

    scope: Optional[str] = None
    """
    Scope of the topic and responsibilities of the agent
    """


class AIModel(BaseModel):
    """AI model metadata and ownership details."""
    model_config = ConfigDict(extra="forbid")

    name: Optional[str] = None
    """
    Name of the AI model
    """

    owner: Optional[str] = None
    """
    Owner of the AI model
    """

    department_executive: Optional[str] = None
    """
    Responsible department or executive
    """

    description: Optional[str] = None
    """
    Description of the AI model
    """


class PhysicalAI(BaseModel):
    """Physical AI system definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    identifier: Optional[str] = None
    """
    Unique identifier for the physical AI system
    """

    name: Optional[str] = None
    """
    Name of the physical AI system
    """

    type: Optional[str] = None
    """
    Type/category of the physical AI system
    """

    sensory_input_source: Optional[str] = None
    """
    Source of sensory input (e.g., camera, microphone, sensors)
    """


class Control(BaseModel):
    """Control definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    identifier: Optional[str] = None
    """
    Unique identifier for the control
    """

    name: Optional[str] = None
    """
    Name of the control
    """

    objective: Optional[str] = None
    """
    Objective or purpose of the control
    """

    domain: Optional[str] = None
    """
    Domain or category the control belongs to
    """


class PromptTemplate(BaseModel):
    """Prompt Template definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    identifier: str | None = None
    """
    A unique identifier for the prompt template used to guide LLM behavior
    """
    name: str | None = None
    """
    The name of the prompt template used to guide LLM behavior
    (e.g., ABC-RAG-Standard-V2)
    """
    description: str | None = None
    """
    The actual prompts used to guide LLM behavior
    """


class Memory(BaseModel):
    """Memory definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    identifier: str | None = None
    """
    A unique identifier for the external system used for long-term data/vector storage
    """
    name: str | None = None
    """
    The name of the external system used for long-term data/vector storage
    (e.g., Atlas-HR-RAG-VectorDB)
    """
    type: str | None = None
    """
    The type of memory storage used (e.g., VECTOR_DB, KEY_VALUE_STORE)
    """


class Tool(BaseModel):
    """Tool definition and attributes configured for the agent."""
    model_config = ConfigDict(extra="forbid")

    identifier: str | None = None
    """
    A unique reference ID for the tool (e.g., PolicySearchTool)
    """
    name: str | None = None
    """
    Name of the tool
    """
    developer_name : str | None = None
    """
    """
    description: str | None = None
    """
    Detailed explanation of the purpose and functionality
    """
    delegation_possible: Optional[bool] = None
    """
    Boolean indicating if the agent can pass the request to another agent
    """
    allowed_delegates: Optional[List[str]] = Field(default_factory=list)
    """
    A list of Agent IDs, which the agent is allowed to delegate to
    """
    input_schema: Optional[str] = None
    """
    The schema defining the expected input format
    """
    output_schema: Optional[str] = None
    """
    The schema defining the expected output format
    """
    parameter_name: Optional[str] = None
    """
    Name of the parameter
    """
    parameter_type: Optional[str] = None
    """
    Required type and format of the parameter
    """
    default_value: Optional[str] = None
    """
    Default value, if any
    """


class KnowledgeSource(BaseModel):
    """Knowledge Source definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    identifier: str | None = None
    """
    A Unique ID for the knowledge source
    """
    name: str | None = None
    """
    A list of all specific knowledge sources (e.g., databases, documents)
    the agent can access
    """
    access_mechanism: str | None = None
    """
    The protocol or service used to retrieve knowledge (e.g., REST API, SQL connector)
    """


class DataSource(BaseModel):
    """Data Source definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    relationship_id: str | None = None
    """
    A unique Relationship ID
    """
    source_object_id: str | None = None
    """
    Unique ID as in the Source system
    """
    source_object_domain: str | None = None
    """
    Domain
    """
    source_object_name: str | None = None
    """
    Object name
    """
    source_object_type: str | None = None
    """
    Type of Source Object (e.g., Agent, MCP Server, Table, Column, View, File, Folder)
    """
    target_object_id: str | None = None
    """
    Unique ID as in the Target system
    """
    target_object_domain: str | None = None
    """
    Domain
    """
    target_object_name: str | None = None
    """
    Object Name
    """
    target_object_type: str | None = None
    """
    Type of Target Object (e.g., Agent, MCP Server, Table, Column, View, File, Folder)
    """
    access_level: str | None = None
    """
    Access Level (READ, WRITE or DELETE)
    """

    parent_relationship_id: Optional[str] = None
    """
    Parent ID, if any
    """

    uses_pii: Optional[bool] = None
    """
    Boolean indicating if the agent uses Personally Identifiable Information (PII) from the data source
    """

    uses_phi: Optional[bool] = None
    """
    Boolean indicating if the agent uses Protected Health Information (PHI) from the data source
    """

    uses_pci: Optional[bool] = None
    """
    Boolean indicating if the agent uses Payment Card Information (PCI) from the data source
    """


class MCPServer(BaseModel):
    """MCP Server definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    name: str | None = None
    """
    The name of the MCP server
    """
    url: str | None = None
    """
    The URL of the MCP server
    """
    version_number: str | None = None
    """
    The version number of the MCP server
    """


class Guardrail(BaseModel):
    """Guardrail definition and attributes used by the agent."""
    model_config = ConfigDict(extra="forbid")

    name: str | None = None
    """
    The name of the guardrail used by the agent (e.g., Prompt Injection, Toxic Content,
    Model Denial-of-Service)
    """
    description: str | None = None
    """
    Description of the guardrail
    """
    model: str | None = None
    """
    The name of the model or application that implements the guardrail
    """


class AIUseCase(BaseModel):
    """AI Use Case definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    identifier: str | None = None
    """
    A unique reference ID for the AI use case
    """
    name: str | None = None
    """
    The name of the AI use case
    """
    description: str | None = None
    """
    Description of the AI use case
    """
    owner: str | None = None
    """
    Name of the business owner of the AI use case
    """
    business_function: str | None = None
    """
    Name of the business function that owns the AI use case
    """
    problem_statement: str | None = None
    """
    Detailed description of the business problem addressed by the AI use case
    """
    priority: str | None = None
    """
    Priority assigned to the AI use case (e.g., Critical, High, Medium, Low)
    """
    status: str | None = None
    """
    Status of the AI use case (e.g., Assess, Authorize, Build, Test, Deploy,
    Completed, Cancelled)
    """

    proposed_by: Optional[str] = None
    """
    Name of the person who proposed the AI use case
    """
    expected_benefits: Optional[str] = None
    """
    Description of the quantitative and qualitative benefits of the AI use case
    """


class Application(BaseModel):
    """Application definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    identifier: str | None = None
    """
    A unique reference ID for the application
    """
    name: str | None = None
    """
    The name of the application
    """
    description: str | None = None
    """
    Description of the application
    """
    business_criticality: str | None = None
    """
    The criticality of the application to the operation of the business
    (e.g., Low, Medium, High)
    """
    emergency_tier: str | None = None
    """
    The impact to the business if the application is inoperable
    (e.g., Non-Critical, Business Critical, Mission Critical)
    """


class BusinessProcess(BaseModel):
    """Business Process definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    identifier: str | None = None
    """
    The ID of the business process that uses the agent
    """
    name: str | None = None
    """
    The human-readable name of the business process
    """
    description: str | None = None
    """
    A brief description of the business process, its significance and relevance
    """
    business_criticality: str | None = None
    """
    The criticality of the process to the operation of the business (e.g., Low,
    Medium, High)
    """


class Regulation(BaseModel):
    """Regulation definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    name: str | None = None
    """
    The name of the regulation (e.g., EU AI Act)
    """
    regulatory_authority: str | None = None
    """
    The name of the regulatory authority (e.g., European Union)
    """
    jurisdiction: str | None = None
    """
    The jurisdiction of the regulation (e.g., European Union, California)
    """
    requirement: str | None = None
    """
    """
    type: str | None = None
    """
    """



class RiskAssessment(BaseModel):
    """Risk Assessment definition and attributes."""
    model_config = ConfigDict(extra="forbid")

    identifier: str | None = None
    """
    The ID of the risk assessment
    """
    name: str | None = None
    """
    The name of the risk assessment (e.g., Agent-02-2Q26)
    """
    assessor: str | None = None
    """
    The name of the assessor
    """
    date: str | None = None
    """
    The date of the risk assessment
    """
    blended_risk_score: float | None = None
    """
    The risk score assigned to the subject (application, business process,
    AI use case, agent) of the risk assessment
    """
    blended_risk_classification: str | None = None
    """
    """
    aivss_score: float | None = None
    """
    """
    aivss_classification: str | None = None
    """
    """
    regulatory_risk_score: float | None = None
    """
    """
    regulatory_risk_classification: str | None = None
    """
    """
    state: str | None = None
    """
    Status of the risk assessment (e.g., Ready to Take, In Progress, Completed,
    Cancelled)
    """

class AdditionalProperties(BaseModel):
    """Additional custom key/value attribute with description."""
    model_config = ConfigDict(extra="forbid")

    key: str | None = None
    """
    The attribute key name
    """
    value: str | None = None
    """
    The attribute value
    """
    description: str | None = None
    """
    Description of what this attribute represents
    """

# -----------------------------
# Tavro Agent Card
# -----------------------------

class TavroAgentCard(AgentCard):
    """
    The AgentCard is a self-describing manifest for an agent. It provides essential
    metadata including the agent's identity, capabilities, skills, supported
    communication methods, and security requirements.
    """
    model_config = ConfigDict(extra="forbid")
    identification: Optional[AgentIdentification] = None
    configuration: Optional[AgentConfiguration] = None
    llm_model: Optional[List[LLMModel]] = None
    prompt_template: Optional[PromptTemplate] = None
    memory: Optional[Memory] = None
    knowledge_source: Optional[KnowledgeSource] = None
    data_source: Optional[List[DataSource]] = None
    tool: Optional[List[Tool]] = None
    mcp_server: Optional[MCPServer] = None
    guardrail: Optional[Guardrail] = None
    ai_use_case: Optional[List[AIUseCase]] = None
    instruction_sets: Optional[List[InstructionSet]] = None
    topics: Optional[List[Topic]] = None
    ai_model: Optional[List[AIModel]] = None
    physical_ai: Optional[List[PhysicalAI]] = None
    control: Optional[List[Control]] = None
    application: Optional[List[Application]] = None
    business_process: Optional[List[BusinessProcess]] = None
    regulation_or_framework: Optional[Regulation] = None
    risk_assessment: Optional[RiskAssessment] = None
    additional_properties: Optional[List[AdditionalProperties]] = None

    @classmethod
    def from_json_file(cls, path: str | Path) -> "TavroAgentCard":
        """
        Load an agent card from a JSON file and validate it as a TavroAgentCard.
        """
        file_path = Path(path)
        data = json.loads(file_path.read_text(encoding="utf-8"))
        return cls.model_validate(data)

    @classmethod
    async def tavro_agent_catalog_async(
        cls,
        *,
        mcp_server_url: str | None = None,
        bearer_token: str | None = None,
        tool_name: str | None = None,
        tool_arguments: dict[str, Any] | None = None,
    ) -> list["TavroAgentCard"]:
        """
        Load agent cards by calling an MCP tool and validate each as a TavroAgentCard.
        """
        from fastmcp.client import Client
        from fastmcp.client.transports import StreamableHttpTransport

        url = mcp_server_url or os.getenv("MCP_SERVER_URL")
        if not url:
            raise ValueError("mcp_server_url is required (or set MCP_SERVER_URL).")

        transport = StreamableHttpTransport(
            url,
            auth=bearer_token,
        )

        client = Client(transport)
        async with client:
            tools = await client.list_tools()
            available_tools = [tool.name for tool in tools]

            resolved_tool_name = tool_name
            if resolved_tool_name is None:
                if len(available_tools) == 1:
                    resolved_tool_name = available_tools[0]
                else:
                    raise ValueError(
                        "tool_name is required. Available tools: "
                        + ", ".join(available_tools)
                    )

            if resolved_tool_name not in available_tools:
                raise ValueError(
                    f"tool_name '{resolved_tool_name}' not found. "
                    f"Available tools: {', '.join(available_tools)}"
                )

            result = await client.call_tool_mcp(
                name=resolved_tool_name,
                arguments=tool_arguments or {},
            )

            if result.isError:
                raise RuntimeError(f"MCP tool '{resolved_tool_name}' returned an error.")

            payload = result.structuredContent
            
            if payload is None:
                payload = cls._parse_tool_text_content(result.content)

            if payload is None:
                raise ValueError(
                    "MCP tool did not return structuredContent or JSON text content."
                )

            if isinstance(payload, dict) and "agent_card_details_list" in payload:
                entries = payload.get("agent_card_details_list")
            elif isinstance(payload, dict) and "result" in payload:
                entries = payload.get("result")
            else:
                entries = payload

            if not isinstance(entries, list):
                raise ValueError("MCP tool did not return a list of agent cards.")

            def camel_to_snake(name: str) -> str:
                out = []
                for i, ch in enumerate(name):
                    if ch.isupper():
                        if i != 0 and (not name[i - 1].isupper()):
                            out.append("_")
                        out.append(ch.lower())
                    else:
                        out.append(ch)
                return "".join(out)

            def convert(obj: Any) -> Any:
                if isinstance(obj, dict):
                    return {camel_to_snake(k): convert(v) for k, v in obj.items()}
                if isinstance(obj, list):
                    return [convert(v) for v in obj]
                return obj

            normalized_entries: list[Any] = []
            for item in entries:
                if isinstance(item, dict) and "agent_card_details_list" in item:
                    nested = item.get("agent_card_details_list")
                    if isinstance(nested, list):
                        normalized_entries.extend(nested)
                        continue
                if isinstance(item, dict) and "agent_card_details" in item:
                    nested = item.get("agent_card_details")
                    if isinstance(nested, dict):
                        item = nested
                normalized_entries.append(item)

            return [cls.model_validate(convert(item)) for item in normalized_entries]

    @classmethod
    def tavro_agent_catalog(
        cls,
        *,
        mcp_server_url: str | None = None,
        tool_name: str | None = None,
        tool_arguments: dict[str, Any] | None = None,
        bearer_token: str | None = None,
    ) -> list["TavroAgentCard"]:
        """
        Synchronous wrapper for tavro_agent_catalog_async.
        """
        import anyio

        try:
            return anyio.run(
                lambda: cls.tavro_agent_catalog_async(
                    mcp_server_url=mcp_server_url,
                    tool_name=tool_name,
                    tool_arguments=tool_arguments,
                    bearer_token=bearer_token,
                )
            )
        except RuntimeError as exc:
            message = str(exc).lower()
            if "already running" in message or "event loop" in message:
                raise RuntimeError(
                    "tavro_agent_catalog must be called outside of an event loop. "
                    "Use `await TavroAgentCard.tavro_agent_catalog_async(...)` instead."
                ) from exc
            raise

    @staticmethod
    def _parse_tool_text_content(content: list[Any] | None) -> dict[str, Any] | None:
        if not content:
            return None

        for item in content:
            text = getattr(item, "text", None)
            if isinstance(text, str):
                try:
                    parsed = json.loads(text)
                except json.JSONDecodeError:
                    continue
                if isinstance(parsed, dict):
                    return parsed

        return None
